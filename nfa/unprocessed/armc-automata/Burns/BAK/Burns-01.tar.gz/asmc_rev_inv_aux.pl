:- use_module('/usr/local/src/FSA/src-compiled/fsa_library').
:- use_module(library(lists)).

%%%%%%%%%%%%%%%%%%%%%%%%

:- fsa_regex_atom_compile('{}',E),assertz(empty(E)).
:- fsa_regex_atom_compile('{?}*',E),assertz(sig_star(E)).

%%......................

:- fsa_regex_compile(file(init),Init),assertz(bad(Init)).

%%......................

:- fsa_regex_compile(file(itrs),TRS),assertz(itrs(TRS)).

:- fsa_regex_compile(inverse(file(itrs)),ITRS),assertz(trs(ITRS)).

%%......................

:- fsa_regex_compile(complement(file(imux)),NMUX),assertz(init(NMUX)).

%%......................

:- bad(Bad),init(Init),assertz(abs_lang([Init,Bad])).

:- retract(abs_lang(AL)),fsa_regex_compile(file(iab1),P),assertz(abs_lang([P|AL])). 

:- retract(abs_lang(AL)),fsa_regex_compile(file(iab2),P),assertz(abs_lang([P|AL])).

%% Manually added to detect presence of a process at b (although iab2 & 3 should suffice)
:- retract(abs_lang(AL)),fsa_regex_compile(file(iab2xxx),P),assertz(abs_lang([P|AL])).

:- retract(abs_lang(AL)),fsa_regex_compile(file(iab3),P),assertz(abs_lang([P|AL])). 

:- retract(abs_lang(AL)),fsa_regex_compile(file(iab4),P),assertz(abs_lang([P|AL])).

:- retract(abs_lang(AL)),fsa_regex_compile(file(iab5),P),assertz(abs_lang([P|AL])). 

%% Manually added to detect presence of a process at d (although iab5 & 6 should suffice)
%:- retract(abs_lang(AL)),fsa_regex_compile(file(iab5xxx),P),assertz(abs_lang([P|AL])).

:- retract(abs_lang(AL)),fsa_regex_compile(file(iab6),P),assertz(abs_lang([P|AL])).

:- retract(abs_lang(AL)),fsa_regex_compile(file(iab7),P),assertz(abs_lang([P|AL])).

%% Manually added to detect presence of a process at e
%:- retract(abs_lang(AL)),fsa_regex_compile(file(iab7xxx),P),assertz(abs_lang([P|AL])).

:- retract(abs_lang(AL)),fsa_regex_compile(file(iab8),P),assertz(abs_lang([P|AL])).

:- abs_lang(AL),assertz(cp_abs_lang(AL)).

%%%%%%%%%%%%%%%%%%%%%%%%

:- assertz(max_tuple(6)).
:- assertz(max_for_appl_tuples(15)).

:- dynamic with_self_loop_acclr/0.

:- assertz(with_self_loop_acclr).

%%%%%%%%%%%%%%%%%%%%%%%%



%% :- use_module('/usr/local/src/FSA/src-compiled/fsa_library').
%% :- use_module(library(lists)).

:- consult('/usr/local/src/FSA/src-compiled/fsa_library').

%%%%%%%%%%%%%%%%%%%%%%%%

:- fsa_regex_atom_compile('{}',E),assertz(empty(E)).
:- fsa_regex_atom_compile('{?}*',E),assertz(sig_star(E)).

%%......................

:- fsa_regex_compile(file(init),Init),assertz(init(Init)).

%%......................

:- fsa_regex_compile(file(itrs),TRS),assertz(trs(TRS)).

:- fsa_regex_compile(inverse(file(itrs)),ITRS),assertz(itrs(ITRS)).

%%......................

:- fsa_regex_compile(file(imux),MUX),assertz(good(MUX)).

:- good(Good),fsa_regex_compile(complement(fa(Good)),Bad),assertz(bad(Bad)).

%%......................

:- good(Good),init(Init),assertz(pred_lang([Init,Good])).

:- retract(pred_lang(PL)),fsa_regex_compile(file(ipred1),P),assertz(pred_lang([P|PL])). 

:- retract(pred_lang(PL)),fsa_regex_compile(file(ipred2),P),assertz(pred_lang([P|PL])).

%% Manually added to detect presence of a process at b (however, ipred2 & 3 suffice)
%% :- retract(pred_lang(PL)),fsa_regex_compile(file(ipred2xxx),P),assertz(pred_lang([P|PL])).

:- retract(pred_lang(PL)),fsa_regex_compile(file(ipred3),P),assertz(pred_lang([P|PL])). 

:- retract(pred_lang(PL)),fsa_regex_compile(file(ipred4),P),assertz(pred_lang([P|PL])).

:- retract(pred_lang(PL)),fsa_regex_compile(file(ipred5),P),assertz(pred_lang([P|PL])). 

%% Manually added to detect presence of a process at d (however, ipred5 & 6 suffice)
%% :- retract(pred_lang(PL)),fsa_regex_compile(file(ipred5xxx),P),assertz(pred_lang([P|PL])).

:- retract(pred_lang(PL)),fsa_regex_compile(file(ipred6),P),assertz(pred_lang([P|PL])).

:- retract(pred_lang(PL)),fsa_regex_compile(file(ipred7),P),assertz(pred_lang([P|PL])).

%% Manually added to detect presence of a process at e (however, turns out unnecessary)
%% :- retract(pred_lang(PL)),fsa_regex_compile(file(ipred7xxx),P),assertz(pred_lang([P|PL])).

:- retract(pred_lang(PL)),fsa_regex_compile(file(ipred8),P),assertz(pred_lang([P|PL])).

%% :- pred_lang(PL),assertz(cp_pred_lang(PL)).

%%%%%%%%%%%%%%%%%%%%%%%%

%% Choose some of the below abstraction methods:

%% Abstraction based on classical language operations:

%% abstract(State,AbsState) :- abstr_lang(State,AbsState).

max_tuple(3).
max_for_appl_tuples(30).

%% Abstraction based on collapsing:

abstract(State,AbsState) :- abstr_coll(State,AbsState).

%% Testing emptiness of intersectins of abstractions and predicates:
%% Requires new_pred to be initially asserted (see below) and its use enabled in the sources.

%% abstract(State,AbsState) :- abstr_coll_debug(State,AbsState).

%%%%%%%%%%%%%%%%%%%%%%%%

:- dynamic with_self_loop_acclr/0.

%% with_self_loop_acclr.

%%%%%%%%%%%%%%%%%%%%%%%%

%% For producing a separate list of newly added predicates 
%% or debugging the collapsing method...

new_pred([]).

%%%%%%%%%%%%%%%%%%%%%%%%

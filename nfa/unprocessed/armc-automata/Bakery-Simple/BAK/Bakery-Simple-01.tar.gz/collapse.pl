%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Basic predicates
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

empty_intrs(A1,A2) :- fsa_regex_compile(intersect(fa(A1),fa(A2)),I), empty(I).

%-------------------------------------------------------------------------------

add_to_set(Elem,SetL,SetL) :- member(Elem,SetL), !.

add_to_set(Elem,SetL,[Elem|SetL]).

%...............................................................................

%%% Removes just the first occurrence of Elem (if any)

rem_from_set(Elem,[Elem|SetL],SetL) :- !.

rem_from_set(Elem1,[Elem2|SetL],[Elem2|NewSetL]) :- rem_from_set(Elem1,SetL,NewSetL).

%-------------------------------------------------------------------------------

in_set_of(Elem,Key,TbL) :- member([Key,SetL],TbL),member(Elem,SetL).

%...............................................................................

rem_set_of(Key,[[Key,SetL]|TbL],SetL,TbL) :- !.

rem_set_of(Key,[X|TbL],SetL,[X|NewTbL]) :- rem_set_of(Key,TbL,SetL,NewTbL).

%...............................................................................

add_to_set_of(Elem,Key,TbL,[[Key,NewSetL]|NewTbLa]) :-
  ( (rem_set_of(Key,TbL,SetL,NewTbLa), !, add_to_set(Elem,SetL,NewSetL));
    (NewSetL=[Elem],NewTbLa=TbL) ).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Abstraction by collapsing
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Labelling states of a "concrete" automaton by states of a "predicate" automaton
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

new_for_conc([[QConc,QPred]|BSmtReachL],ToDoTbL,NewToDoTbL,ConcTbL,NewConcTbL) :-
  ( (in_set_of(QPred,QConc,ConcTbL), !,
     new_for_conc(BSmtReachL,ToDoTbL,NewToDoTbL,ConcTbL,NewConcTbL));
    (add_to_set_of(QPred,QConc,ConcTbL,NewConcTbLa),
     add_to_set_of(QPred,QConc,ToDoTbL,NewToDoTbLa),
     new_for_conc(BSmtReachL,NewToDoTbLa,NewToDoTbL,NewConcTbLa,NewConcTbL)) ), !.

new_for_conc([],ToDoTbL,ToDoTbL,ConcTbL,ConcTbL).

%-------------------------------------------------------------------------------

%%% Removes the first compatible transition (with a nonempty intersection of the labels)

rem_compatible_from_set([trans(QPred1,B,QPred2)|NewTrPredL],A,QPred2,QPred1,NewTrPredL) :-
  fsa_preds:conjunction(A,B,_),
  !.
  
rem_compatible_from_set([_|TrPredL],A,QPred2,QPred1,NewTrPredL) :-
  rem_compatible_from_set(TrPredL,A,QPred2,QPred1,NewTrPredL).

%...............................................................................


do_step_back(trans(QConc1,A,QConc2),TrPredL,QPred2,BSmtReachL) :-
  rem_compatible_from_set(TrPredL,A,QPred2,QPred1,NewTrPredL),
  !,
  do_step_back(trans(QConc1,A,QConc2),NewTrPredL,QPred2,BSmtReachLa),
  BSmtReachL=[[QConc1,QPred1]|BSmtReachLa],
  !.

do_step_back(_,_,_,[]).

%...............................................................................

step_back([trans(QConc1,A,QConc2)|TrConcL],TrPredL,QConc2,QPred2,BSmtReachL) :-
  !,
  do_step_back(trans(QConc1,A,QConc2),TrPredL,QPred2,BSmtReachLa),
  step_back(TrConcL,TrPredL,QConc2,QPred2,BSmtReachLb),
  append(BSmtReachLa,BSmtReachLb,BSmtReachL),
  !.

step_back([_|TrConcL],TrPredL,QConc2,QPred2,BSmtReachL) :-
  !,
  step_back(TrConcL,TrPredL,QConc2,QPred2,BSmtReachL),
  !.

step_back([],_,_,_,[]).

%-------------------------------------------------------------------------------

%%% In case of troubles with the size of Prolog stacks, this can be optimized:

repeat_step_back([[QConc,[QPred|QPredL]]|ToDoTbL],ConcTbL,NewConcTbL,ConcTrL,PredTrL) :-
  !,
  step_back(ConcTrL,PredTrL,QConc,QPred,BSmtReachL),
  NewToDoTbLa=[[QConc,QPredL]|ToDoTbL],
  new_for_conc(BSmtReachL,NewToDoTbLa,NewToDoTbLb,ConcTbL,NewConcTbLb),
  repeat_step_back(NewToDoTbLb,NewConcTbLb,NewConcTbL,ConcTrL,PredTrL),
  !.

repeat_step_back([[_,[]]|ToDoTbL],ConcTbL,NewConcTbL,ConcTrL,PredTrL) :- 
  !,
  repeat_step_back(ToDoTbL,ConcTbL,NewConcTbL,ConcTrL,PredTrL),
  !.
  
repeat_step_back([],ConcTbL,ConcTbL,_,_).

%-------------------------------------------------------------------------------

%%% We label each final concrete states by all final predicate states AND
%%% all other states by the empty set...

initial_labels(N,FConcL,FPredL,[[N,FPredL]|LabTabL]) :- 
  member(N,FConcL),
  !,
  NN is N-1,
  initial_labels(NN,FConcL,FPredL,LabTabL), !.

initial_labels(N,FConcL,FPredL,[[N,[]]|LabTabL]) :-  
  N >= 0,
  !,
  NN is N-1,
  initial_labels(NN,FConcL,FPredL,LabTabL), !.

initial_labels(_,_,_,[]).

%-------------------------------------------------------------------------------

add_labels([[Q,LabL]|LabTabL]) :-
  sort(LabL,SortLabL),
  ( (retract(label(Q,QLabLL)), !, assertz(label(Q,[SortLabL|QLabLL])));
    (assertz(label(Q,[SortLabL]))) ),
  add_labels(LabTabL),
  !.

add_labels([]).

%-------------------------------------------------------------------------------

%%% For other predicate modules than r(fsa_preds), a modification of rem_compatible_from_set
%%% is necessary...

compute_labels(fa(PredModule,ConcStN,_,ConcFinL,ConcTrL,_),fa(PredModule,_,_,PredFinL,PredTrL,_)) :-
  ( (PredModule\=r(fsa_preds), !, write('Predicate module fsa_preds required!'),nl,halt); true ),
  ConcStNN is ConcStN-1,
  initial_labels(ConcStNN,ConcFinL,PredFinL,LabTabLa),
  repeat_step_back(LabTabLa,LabTabLa,LabTabL,ConcTrL,PredTrL),
  %% write('A set of labels: '),write(LabTabL),nl,
  add_labels(LabTabL).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Collapsing an automaton
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

collect_class(LabLL,[Q|QLa]) :-
  retract(label(Q,LabLL)),
  !,
  collect_class(LabLL,QLa),
  !.

collect_class(_,[]) :- !.

%-------------------------------------------------------------------------------

collect_partition([[Q|OthersL]|PartitionL]) :-
  retract(label(Q,LabLL)),
  !,
  collect_class(LabLL,OthersL),
  collect_partition(PartitionL),
  !.

collect_partition([]) :- !.

%-------------------------------------------------------------------------------

find_class([ClL|_],Q,ClL) :- member(Q,ClL), !.

find_class([_|PartitionL],Q,ClL) :- find_class(PartitionL,Q,ClL).

%-------------------------------------------------------------------------------

adjust_trans(PartitionL,[trans(Q1,A,Q2)|TrL],[trans(Cl1L,A,Cl2L)|NewTrL]) :-
  find_class(PartitionL,Q1,Cl1L),
  find_class(PartitionL,Q2,Cl2L),
  adjust_trans(PartitionL,TrL,NewTrL),
  !.

adjust_trans(_,[],[]).

%...............................................................................

adjust_st(PartitionL,[Q|QL],[ClL|NewQL]) :-
  find_class(PartitionL,Q,ClL),
  adjust_st(PartitionL,QL,NewQL),
  !.

adjust_st(_,[],[]).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Abstracting automata by collapsing their states
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

do_abstr_coll(Conc,[Pred|PredL]) :-
  compute_labels(Conc,Pred),
  do_abstr_coll(Conc,PredL),
  !.

do_abstr_coll(_,[]) :- !.

%-------------------------------------------------------------------------------

abstr_coll(Conc,Abstr) :-
  pred_lang(PredL),
  write('Labelling wrt. the particular predicate automata...'),nl,
  do_abstr_coll(Conc,PredL),
  write('Computing the partition...'),nl,
  collect_partition(PartitionL),
  %% write('Partition: '),write(PartitionL),nl,
  Conc=fa(ConcSym,_,ConcIniL,ConcFinL,ConcTrL,_),
  adjust_trans(PartitionL,ConcTrL,NewConcTrL),
  adjust_st(PartitionL,ConcFinL,NewConcFinL),
  adjust_st(PartitionL,ConcIniL,NewConcIniL),
  fsa_construct_rename_states(ConcSym,NewConcIniL,NewConcFinL,NewConcTrL,[],Abstr1),
  fsa_regex_compile(minimize(fa(Abstr1)),Abstr).

%-------------------------------------------------------------------------------

%%% Requires new_pred to be initially asserted and its use enabled in the sources.

abstr_coll_debug(State,AbsState) :- 
  abstr_coll(State,AbsState), check_coll(State,AbsState).

%...............................................................................

check_coll(State,AbsState) :-
  new_pred(PredL),
  do_check_coll(PredL,State,AbsState),
  %% write('vvv Check of collapsing passed...'),nl,
  !.

%...............................................................................

do_check_coll([Pred|PredL],State,AbsState) :-
  fsa_regex_compile(intersect(fa(Pred),fa(AbsState)),Intrs),
  ( (empty(Intrs), !, do_check_coll(PredL,State,AbsState));
    (write('xxx Check of collapsing failed...'),nl,
     fsa_write_file(xxxAbs,AbsState),
     fsa_write_file(xxxConc,State),
     fsa_write_file(xxxPred,Pred),
     fsa_regex_compile(intersect(fa(Pred),fa(State)),Intrs2),
     ( (empty(Intrs2), !, write('Disjunct with the concrete state...'),nl);
       (write('NOT disjunct with the concrete state either...'),nl) ),
     trace) ), !.

do_check_coll([],_,_) :- !.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Abstraction by classical language operations
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Abstracting by single languages
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

sngl_abstr(P,used) :- 
  state(State),
  empty_intrs(State,P), !,
  fsa_regex_compile(complement(fa(P)),NP),
  retract(abs_state(AbsState1)),
  fsa_regex_compile(intersect(fa(NP),fa(AbsState1)),AbsState2),
  %% AbsState2=fa(_,NS,_,_,T,_),length(T,NT),
  %% write('Abstraction refined to: '),write(NS),write(','),write(NT),nl,
  assertz(abs_state(AbsState2)), !.

sngl_abstr(P,used) :- 
  state(State),
  fsa_regex_compile(complement(fa(P)),NP),
  empty_intrs(State,NP), !,
  retract(abs_state(AbsState1)),
  fsa_regex_compile(intersect(fa(P),fa(AbsState1)),AbsState2),
  %% AbsState2=fa(_,NS,_,_,T,_),length(T,NT),
  %% write('Abstraction refined to: '),write(NS),write(','),write(NT),nl,
  assertz(abs_state(AbsState2)), !.

sngl_abstr(_,unused).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Abstracting by tuples of languages
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

gen_pos_neg([],AlrGen) :- 
  state(State),
  fsa_regex_compile(complement(fa(AlrGen)),NP),
  empty_intrs(State,NP), !,
  retract(abs_state(AbsState1)),
  fsa_regex_compile(intersect(fa(AlrGen),fa(AbsState1)),AbsState2),
  %% AbsState2=fa(_,NS,_,_,T,_),length(T,NT),
  %% write('Abstraction refined to: '),write(NS),write(','),write(NT),nl,
  assertz(abs_state(AbsState2)), !,
  fail.

gen_pos_neg([],_) :- !, fail.

gen_pos_neg([X|GenFromL],AlrGen) :-
  ( (fsa_regex_compile(union(fa(X),fa(AlrGen)),NewGen),
     gen_pos_neg(GenFromL,NewGen));
    (fsa_regex_compile(union(complement(fa(X)),fa(AlrGen)),NewGen),
     gen_pos_neg(GenFromL,NewGen)) ).

%-------------------------------------------------------------------------------

generate_tuples(0,_,AlrGenL) :- !, empty(E),gen_pos_neg(AlrGenL,E).

generate_tuples(_,[],_) :- !, fail.

generate_tuples(ToGen,[X|GenFromL],AlrGenL) :-
  NewToGen is ToGen-1,
  ( generate_tuples(NewToGen,GenFromL,[X|AlrGenL]);
    generate_tuples(ToGen,GenFromL,AlrGenL) ).

%-------------------------------------------------------------------------------

tupl_abstr(N,Max,_) :- N>Max, !.

tupl_abstr(N,Max,BaseL) :-
  write('Abstracting by '),write(N),write('-tuples ...'),nl,
  ( (generate_tuples(N,BaseL,[]));
    (true) ),
  NN is N+1,
  tupl_abstr(NN,Max,BaseL).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% The main part of abstracting states by classical language operations
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

do_abstract_lang([P|PredLangL],UnusedL) :-
  sngl_abstr(P,Result),
  ( (Result=used, !,do_abstract_lang(PredLangL,UnusedL));
    (do_abstract_lang(PredLangL,[P|UnusedL])) ), !.

do_abstract_lang([],UnusedL) :-
  length(UnusedL,NUnused),
  write('The number of non-singleton pred. lang.: '),write(NUnused),nl,
  max_for_appl_tuples(MaxForTpl),
  NUnused>MaxForTpl, !.
  
do_abstract_lang([],UnusedL) :-
  max_tuple(Max),
  tupl_abstr(2,Max,UnusedL).

%-------------------------------------------------------------------------------

abstr_lang(State,AbsState) :-
  pred_lang(PredLangL),
  sig_star(SigStar),
  assertz(state(State)),
  assertz(abs_state(SigStar)),
  write('Abstracting post by single languages...'),nl,
  do_abstract_lang(PredLangL,[]),
  retract(state(State)),
  retract(abs_state(AbsState)).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% The main algorithm of A.S.M.C.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

do_one_run(AbsReach,Result,ReachBad) :-
  trs(TRS),
  write('Computing post...'),nl,
  AbsReach=fa(_,NS1,_,_,T1,_),length(T1,NT1),
  write('Abstract source automaton: '),write(NS1),write(','),write(NT1),nl,
  fsa_regex_compile(minimize(range(compose(fa(AbsReach),fa(TRS)))),NewReach),  
  NewReach=fa(_,NS2,_,_,T2,_),length(T2,NT2),
  write('Concrete target automaton: '),write(NS2),write(','),write(NT2),nl,
  bad(Bad),
  write('Intersecting with bad...'),nl,
  fsa_regex_compile(intersect(fa(NewReach),fa(Bad)),ImmReachBad),
  ( (empty(ImmReachBad), !,do_one_run_ph2(AbsReach,NewReach,Result,ReachBad));
    (Result=bad,ReachBad=[ImmReachBad,ImmReachBad],write('XXXXX'),nl) ).

%...............................................................................

do_one_run_ph2(AbsReach,NewReach,Result,ReachBad) :-
  abstract(NewReach,NewAbsReach),
  ( (AbsReach=NewAbsReach, !,Result=good,ReachBad=NewAbsReach); %% Returning the fixpoint
    (write('>>>>>'),nl,do_one_run_ph3(NewAbsReach,Result,ReachBad)) ).

%...............................................................................

do_one_run_ph3(NewAbsReach,Result,ReachBad) :-
  do_one_run(NewAbsReach,SubResult,SubReachBad),
  ( (SubResult=good, !,Result=SubResult,ReachBad=SubReachBad);
    (SubResult=new, !,Result=SubResult,ReachBad=SubReachBad);
    (itrs(ITRS),
     SubReachBad=[SubReachBad1,SubReachBad2],
     write('Computing pre...'),nl,
     fsa_regex_compile(minimize(range(compose(fa(SubReachBad1),fa(ITRS)))),SrcSubReachBad),
     SrcSubReachBad=fa(_,NS1,_,_,T1,_),length(T1,NT1),
     write('After a step back: '),write(NS1),write(','),write(NT1),nl,
     write('Intersecting with reachable...'),nl,
     fsa_regex_compile(intersect(fa(SrcSubReachBad),fa(NewAbsReach)),TrReachBad),
     TrReachBad=fa(_,NS2,_,_,T2,_),length(T2,NT2),
     write('Reachable bad states: '),write(NS2),write(','),write(NT2),nl,
     ( (empty(TrReachBad), !,Result=new,ReachBad=SubReachBad2);  %% Big new pred. lang. (vvv too)
       %% (empty(TrReachBad), !,Result=new,ReachBad=SubReachBad1);  %% Small new pred. lang. (vvv too)
       (Result=bad,ReachBad=[TrReachBad,SrcSubReachBad],write('<<<<<'),nl) )) ).

%-------------------------------------------------------------------------------

one_run(Result,ReachBad) :-
  init(Init),
  %% write('Abstracting init...'),nl, abstract(Init,AbsInit), %% Choose either this or 'v'
  AbsInit=Init,                                               %% Choose either this or '^'
  write('>>>>>'),nl,
  do_one_run(AbsInit,SubResult,SubReachBad),
  ( (SubResult=good, !,Result=SubResult,ReachBad=SubReachBad);
    (SubResult=new, !,Result=SubResult,ReachBad=SubReachBad);
    (itrs(ITRS),
     SubReachBad=[SubReachBad1,SubReachBad2],
     write('Computing pre...'),nl,
     fsa_regex_compile(minimize(range(compose(fa(SubReachBad1),fa(ITRS)))),SrcSubReachBad),
     SrcSubReachBad=fa(_,NS1,_,_,T1,_),length(T1,NT1),
     write('After a step back: '),write(NS1),write(','),write(NT1),nl,
     write('Intersecting with reachable...'),nl,
     fsa_regex_compile(intersect(fa(SrcSubReachBad),fa(AbsInit)),TrReachBad),
     TrReachBad=fa(_,NS2,_,_,T2,_),length(T2,NT2),
     write('After an inters. with reach. states: '),write(NS2),write(','),write(NT2),nl,
     ( (empty(TrReachBad), !,Result=new,ReachBad=SubReachBad2);  %% Big new pred. lang. (^^^ too)
       %% (empty(TrReachBad), !,Result=new,ReachBad=SubReachBad1);  %% Small new pred. lang. (^^^ too)
       (write('Intersecting with init...'),nl,
        fsa_regex_compile(intersect(fa(SrcSubReachBad),fa(Init)),ReallyReachBad),
        ReallyReachBad=fa(_,NS3,_,_,T3,_),length(T3,NT3),
        write('After an inters. with initial states: '),write(NS3),write(','),write(NT3),nl,
        ( (empty(ReallyReachBad), !,Result=new,ReachBad=SrcSubReachBad);
	  (Result=bad,ReachBad=ReallyReachBad) )) )) ).

%-------------------------------------------------------------------------------

do_asmc(N) :-
  write('~~~~~ Run '),write(N),write(':'),nl,
  one_run(Result,ReachBad),
  ( (Result=good, !,write('----- Property holds!'),nl,
     fsa_write_file(reachable,ReachBad) );
    (Result=bad, !,fsa_write_file(error,ReachBad),write('----- Property broken!'),nl);
    (ReachBad=fa(_,Size,_,_,_,_),
     write('In run '),write(N),write(', adding a new pred. aut. with '),
     write(Size),write(' states...'),nl,
     name(N,NL),atom_chars(PN,NL),atom_concat('pr',PN,PP),fsa_write_file(PP,ReachBad),
     retract(pred_lang(PredLangL)),assertz(pred_lang([ReachBad|PredLangL])),
    retract(new_pred(NewPredLangL)),assertz(new_pred([ReachBad|NewPredLangL])),
     %% add_self_loops(ReachBad,ReachBadSelfLoops), %% Adding self-loops everywhere
     %% retract(pred_lang(PredLangL)),assertz(pred_lang([ReachBad,ReachBadSelfLoops|PredLangL])),     
     ( (with_self_loop_acclr, !,try_self_loop_acclr(N,[ReachBad|PredLangL])); true ),
     NN is N+1,
     do_asmc(NN)) ), !.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% A simple counterexample-analysis acceleration based on adding self loops
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Detection of widening situations in 3 steps.

% try_self_loop_acclr(N,[P1,P2,P3,P4|_]) :-
%   N>3,
%   P1=fa(_,Size1,_,_,_,_),
%   P2=fa(_,Size2,_,_,_,_),
%   P3=fa(_,Size3,_,_,_,_),
%   P4=fa(_,Size4,_,_,_,_),
%   Delta is Size1-Size2,
%   Delta is Size2-Size3,
%   Delta is Size3-Size4, !,
%   self_loop_acclr(P4,P3,P3acclr),
%   P3acclr=fa(_,Size,_,_,_,_),
%   write('After counterexample-analysis acceleration in run '), write(N),
%   write(', adding a pred. aut. with '),write(Size),write(' states...'),nl,
%   name(N,NL),atom_chars(PN,NL),atom_concat('pr_acclr',PN,PP),fsa_write_file(PP,P3acclr),
%   %% retract(max_tuple(NPred)),NNPred is NPred+2,assertz(max_tuple(NNPred)),
%   retract(pred_lang(PredLangL)),assertz(pred_lang([P3acclr|PredLangL])), !.

%% Detection of widening situations in 2 steps.

try_self_loop_acclr(N,[P2,P3,P4|_]) :-
  N>2,
  P2=fa(_,Size2,_,_,_,_),
  P3=fa(_,Size3,_,_,_,_),
  P4=fa(_,Size4,_,_,_,_),
  Delta is Size2-Size3,
  Delta is Size3-Size4, !,
  self_loop_acclr(P4,P3,P3acclr),
  P3acclr=fa(_,Size,_,_,_,_),
  write('After counterexample-analysis acceleration in run '), write(N),
  write(', adding an abs. aut. with '),write(Size),write(' states...'),nl,
  name(N,NL),atom_chars(PN,NL),atom_concat('pr_acclr',PN,PP),fsa_write_file(PP,P3acclr),
  %% retract(max_tuple(NPred)),NNPred is NPred+2,assertz(max_tuple(NNPred)),
  retract(pred_lang(PredLangL)),assertz(pred_lang([P3acclr|PredLangL])), !.
  
try_self_loop_acclr(_,_).

%-------------------------------------------------------------------------------

self_loop_acclr(A,B1,B2) :-
  A=fa(_,_,[Ai],_,AtL,_),
  B1=fa(_,Bs1,[Bi1],Bf1L,Bt1L,Bj1L),
  assertz(at(AtL)),
  assertz(bt(Bt1L)), 
  assertz(loopon([])),
  cmp_from(Ai,Bi1),
  retract(at(_)),
  retract(bt(_)),
  retract(loopon(SL)),
  tr_to_loop(SL,SL,Bt1L,LoopL),
  %% write('Acceleration is adding the following loops: '),write(LoopL),nl,
  append(Bt1L,LoopL,Bt2L),
  fsa_construct(Bs1,[Bi1],Bf1L,Bt2L,Bj1L,B2).

%-------------------------------------------------------------------------------

cmp_from(As,Bs) :-
  retract(bt(Bt1L)),
  find_from(Bs,Bt1L,BstL,Bt2L),
  assertz(bt(Bt2L)),
  cmp_from_using(As,BstL).

cmp_from_using(As1,[trans(Bs1,A,Bs2)|BstL]) :-
  at(AtL),
  ( (member(trans(As1,A,As2),AtL), !,cmp_from(As2,Bs2),cmp_from_using(As1,BstL));
    (retract(loopon(L)),assertz(loopon([Bs1|L]))) ),
  !.

cmp_from_using(_,[]).

%-------------------------------------------------------------------------------

find_from(S1,[trans(S1,A,S2)|TrL1],[trans(S1,A,S2)|TrL2],TrL3) :-
  find_from(S1,TrL1,TrL2,TrL3), !.

find_from(S1,[trans(S2,A,S3)|TrL1],TrL2,[trans(S2,A,S3)|TrL3]) :-
  find_from(S1,TrL1,TrL2,TrL3), !.

find_from(_,_,[],[]).

%-------------------------------------------------------------------------------

do_tr_to_loop(S1,ForbiddenL,[trans(S1,_,S2)|TrL1],TrL2) :-
  member(S2,ForbiddenL), !,
  do_tr_to_loop(S1,ForbiddenL,TrL1,TrL2), !.

do_tr_to_loop(S1,ForbiddenL,[trans(S1,A,_)|TrL1],[trans(S1,A,S1)|TrL2]) :-
  do_tr_to_loop(S1,ForbiddenL,TrL1,TrL2), !.

do_tr_to_loop(S1,ForbiddenL,[_|TrL1],TrL2) :-
  do_tr_to_loop(S1,ForbiddenL,TrL1,TrL2), !.

do_tr_to_loop(_,_,[],[]).

%-------------------------------------------------------------------------------

tr_to_loop([S|SL],ForbiddenL,TrL,TrL3) :-
  do_tr_to_loop(S,ForbiddenL,TrL,TrL1),
  tr_to_loop(SL,ForbiddenL,TrL,TrL2),
  append(TrL1,TrL2,TrL3), !.

tr_to_loop([],_,_,[]).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Adding self-loops everywhere
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

do_add_self_loops([trans(S,A,S)|TrL1],[trans(S,A,S)|TrL2]) :-
  do_add_self_loops(TrL1,TrL2), !.

do_add_self_loops([trans(S1,A,S2)|TrL1],[trans(S1,A,S1),trans(S1,A,S2)|TrL2]) :-
  do_add_self_loops(TrL1,TrL2), !.
  
do_add_self_loops([],[]).
  
add_self_loops(fa(X,S,I,F,T1,Y),A) :-
  do_add_self_loops(T1,T2),
  A=fa(X,S,I,F,T2,Y).

%%  fsa_regex_compile(minimize(fa(fa(X,S,I,F,T2,Y))),A).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% That's all falks...
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


















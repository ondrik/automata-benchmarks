:- use_module('/usr/local/src/FSA/src-compiled/fsa_library').

%%%%%%%%%%%%%%%%%%%%%%%%

:- fsa_regex_atom_compile('{}',E),assertz(empty(E)).
:- fsa_regex_atom_compile('{?}*',E),assertz(sig_star(E)).

%%......................

:- fsa_regex_compile(file(init),Init),assertz(bad(Init)).

%%......................

:- fsa_regex_compile(file(trel),TRS),assertz(itrs(TRS)).

:- fsa_regex_compile(inverse(file(trel)),ITRS),assertz(trs(ITRS)).

%%......................

:- fsa_regex_compile(complement(file(mux)),NMUX),assertz(init(NMUX)).

%%......................

:- bad(Bad),init(Init),assertz(abs_lang([Init,Bad])).

:- retract(abs_lang(AL)),fsa_regex_compile(file(abs2),P),assertz(abs_lang([P|AL])).

:- retract(abs_lang(AL)),fsa_regex_compile(file(abs3),P),assertz(abs_lang([P|AL])). 

:- retract(abs_lang(AL)),fsa_regex_compile(file(abs4),P),assertz(abs_lang([P|AL])).

%%%% The result of manual widining - to be used with max_tuple(1)
%%:- retract(abs_lang(AL)),fsa_regex_compile(file(absxxx),P),assertz(abs_lang([P|AL])).

:- abs_lang(AL),assertz(cp_abs_lang(AL)).

%%%%%%%%%%%%%%%%%%%%%%%%

:- assertz(max_tuple(3)).
:- assertz(max_for_appl_tuples(7)).

%%%%%%%%%%%%%%%%%%%%%%%%

